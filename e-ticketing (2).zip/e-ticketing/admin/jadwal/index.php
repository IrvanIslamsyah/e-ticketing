<?php

$page = "Data Jadwal Penerbangan";

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");


?>

<?php require '../../layouts/sidebar_admin.php'; ?>

<div class="flex-1 p-4">

    <h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
    <h1>Halaman Data Jadwal Penerbangan</h1>

    <a href="tambah.php">Tambah</a>
    <table class="min-w-full border rounded-lg overflow-hidden">
        <thead class="bg-gray-800 text-white">
            <tr>
                <th class="py-2 px-4">No</th>
                <th class="py-2 px-4">Nama Maskapai</th>
                <th class="py-2 px-4">Kapasitas</th>
                <th class="py-2 px-4">Rute Asal</th>
                <th class="py-2 px-4">Rute Tujuan</th>
                <th class="py-2 px-4">Tanggal Pergi</th>
                <th class="py-2 px-4">Waktu Berangkat</th>
                <th class="py-2 px-4">Waktu Tiba</th>
                <th class="py-2 px-4">Harga</th>
                <th class="py-2 px-4">Aksi</th>
            </tr>
        </thead>
        
        <tbody class="bg-gray-600 text-center">
            <?php $no = 1; ?>
            <?php foreach($jadwal as $data) : ?>
            <tr>
                <td class="py-4 px-1"><?= $no; ?></td>
                <td class="py-4 px-1"><?= $data["nama_maskapai"]; ?></td>
                <td class="py-4 px-1"><?= $data["kapasitas"]; ?></td>
                <td class="py-4 px-1"><?= $data["rute_asal"]; ?></td>
                <td class="py-4 px-1"><?= $data["rute_tujuan"]; ?></td>
                <td class="py-4 px-1"><?= $data["tanggal_pergi"]; ?></td>
                <td class="py-4 px-1"><?= $data["waktu_berangkat"]; ?></td>
                <td class="py-4 px-1"><?= $data["waktu_tiba"]; ?></td>
                <td class="py-4 px-1">Rp <?= number_format($data["harga"]); ?></td>
                <td class="py-4 px-1">
                    <a href="edit.php?id=<?= $data["id_jadwal"]; ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-1 px-1 rounded">Edit</a>
                    <a href="hapus.php?id=<?= $data["id_jadwal"]; ?>" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')" class="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-1 rounded">Hapus</a>
                </td>
            </tr>
            <?php $no++; ?>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

